<p align="center">
    <img src="./src/main/resources/galosphere.png">
</p>

<p align="center">

  <a href="https://discord.gg/HSyVPZTFvF">
    <img alt="Discord" src="https://img.shields.io/discord/740028725654978610?color=9cb4b2&label=%20&labelColor=5d7170&logoColor=white&style=for-the-badge&logo=discord">
  </a>

  <a href="https://www.curseforge.com/minecraft/mc-mods/galosphere">
    <img alt="CurseForge" src="https://img.shields.io/badge/Curseforge-Orcinus?label=&color=9cb4b2&labelColor=5d7170&style=for-the-badge&logo=Curseforge&logoColor=white">
  </a>

  <a href="https://twitter.com/OrcinusWasTaken">
    <img alt="Twitter" src="https://img.shields.io/twitter/follow/OrcinusWasTaken?label=&color=9cb4b2&labelColor=5d7170&style=for-the-badge&logo=Twitter&logoColor=white">
  </a>

</p>