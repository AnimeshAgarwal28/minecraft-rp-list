<p align="center"><img src="https://i.ibb.co/zrC8mms/icon.png" alt="Logo" width="400"></p>
<h3 align="center">Mod is still in major development</h3>
<p align="center">
If you are interested in testing the mod as I work on it, download the files on the <a href="https://github.com/ianm1647/expandeddelight/actions">Actions</a> page.</p>

<p align="center"> Current features are listed <a href="https://github.com/ianm1647/expandeddelight/issues/1">here</a></p>

<h4 align="center"> The mod is now available on CurseForge!</p>
<p align="center"><a href="https://www.curseforge.com/minecraft/mc-mods/expanded-delight"><img src="https://i.ibb.co/fDHvmnz/logo-4x33v.png" alt="logo-4x33v" border="0"></a></p>
